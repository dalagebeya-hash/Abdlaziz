// Telegram admin username (without the @ symbol).
const TELEGRAM_ADMIN = 'Abbbbb';

// Enter your actual selling prices in ETB per 50kg bag. Keep null until confirmed.
const PRODUCT_PRICES = { opc: 2180, ppc: 2180, dangote: 2200 };

const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

document.querySelectorAll('.order-btn').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('productSelect').value = button.dataset.product;
    document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => document.querySelector('#orderForm input[name="name"]').focus(), 500);
  });
});

// Display only confirmed prices; never show made-up prices.
const priceKeys = ['opc', 'ppc', 'dangote'];
priceKeys.forEach(key => {
  const target = document.querySelector(`[data-price="${key}"]`);
  if (target && Number.isFinite(PRODUCT_PRICES[key]) && PRODUCT_PRICES[key] > 0) {
    target.textContent = `${PRODUCT_PRICES[key].toLocaleString()} ETB`;
  }
});

document.getElementById('orderForm').addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const message = [
    'የሲሚንቶ ትዕዛዝ ጥያቄ',
    `ስም: ${form.get('name')}`,
    `ስልክ: ${form.get('phone')}`,
    `ምርት: ${form.get('product')}`,
    `ብዛት: ${form.get('quantity') || 'አልተገለጸም'} ከረጢት`,
    `ተጨማሪ መረጃ: ${form.get('details') || 'የለም'}`
  ].join('\n');
  // Open the admin's Telegram chat and prefill the order message.
  const telegramUrl = `https://t.me/${TELEGRAM_ADMIN}?text=${encodeURIComponent(message)}`;
  window.open(telegramUrl, '_blank', 'noopener');
});

document.getElementById('year').textContent = new Date().getFullYear();

// Reveal sections smoothly as the visitor scrolls.
const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add('visible'));
}
